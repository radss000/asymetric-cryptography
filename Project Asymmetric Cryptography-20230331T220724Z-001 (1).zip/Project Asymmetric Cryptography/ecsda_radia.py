from rfc7448 import x25519, add, computeVcoordinate, mult
from Crypto.Hash import SHA256
from random import randint
from algebra import mod_inv

p = 2**255 - 19
ORDER = 2**252 + 27742317777372353535851937790883648493

BaseU = 9
BaseV = computeVcoordinate(BaseU)


def H(message):
    h = SHA256.new(message)
    return int(h.hexdigest(), 16)


def ECDSA_generate_nonce():
    return randint(1, ORDER - 1)


def ECDSA_generate_keys():
    # Generate private key
    private_key = randint(1, ORDER - 1)

    # Generate public key
    public_key = mult(private_key, (BaseU, BaseV), p, ORDER)

    return private_key, public_key



def ECDSA_sign(message, private_key):
    z = H(message)
    k = ECDSA_generate_nonce()
    r, y = mult(k, (BaseU, BaseV))
    s = mod_inv(k, ORDER) * (z + r * private_key) % ORDER
    return r, s


def ECDSA_verify(message, public_key, signature):
    r, s = signature
    if not (0 < r < ORDER and 0 < s < ORDER):
        return False
    z = H(message)
    w = mod_inv(s, ORDER)
    u1 = z * w % ORDER
    u2 = r * w % ORDER
    x, y = add(mult(u1, (BaseU, BaseV)), mult(u2, public_key))
    if r == x % ORDER:
        return True
    return False


# Test values
message = b'A very very important message!'
k = 0x2c92639dcf417afeae31e0f8fddc8e48b3e11d840523f54aaa97174221faee6
x = 0xc841f4896fe86c971bedbcf114a6cfd97e4454c9be9aba876d5a195995e2ba8
r_expected = 0x429146a1375614034c65c2b6a86b2fc4aec00147f223cb2a7a22272d4a3fdd2
s_expected = 0xf23bcdebe2e0d8571d195a9b8a05364b14944032032eeeecd22a0f6e94f8f33

# Generate keys and sign message
private_key, public_key = ECDSA_generate_keys()
signature = ECDSA_sign(message, x)

# Verify signature
assert ECDSA_verify(message, public_key, signature)

# Check if obtained signature matches expected values
assert signature[0] == r_expected
assert signature[1] == s_expected
