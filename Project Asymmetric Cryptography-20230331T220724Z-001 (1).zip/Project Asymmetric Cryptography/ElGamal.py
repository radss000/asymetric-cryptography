from secrets import randbelow
from hashlib import sha256
from algebra import bytes_to_int, int_to_bytes, mod_inv, bruteLog


# MODP Group 24 parameters
p = 2**2048 - 2**1984 + 1
print("p value is equal to:", p)
g = 2
q = (p - 1) // 2

def EG_KeyGen():
    """Generate a new El Gamal key pair"""
    x = randbelow(q)
    y = pow(g, x, p)
    return (x, y)

def EG_Encrypt(m):
    """Encrypt message m using El Gamal encryption"""
    k = randbelow(q)
    r = pow(g, k, p)
    c = (pow(y, k, p) * m) % p
    return (r, c)


def EGA_Encrypt(m):
    """Encrypt message m using additive El Gamal encryption"""
    k = randbelow(q)
    r = pow(g, k, p)
    c = (pow(y, k, p) + m) % p
    return (r, c)

def EG_Decrypt(r, c, x):
    """Decrypt El Gamal ciphertext (r, c) using key x"""
    m = (c * mod_inv(pow(r, x, p), p)) % p
    return m

# 2.2 Homomorphic encryption: multiplicative version

# Define messages
m1 = 0x2661b673f687c5c3142f806d500d2ce57b1182c9b25bfe4fa09529424b
m2 = 0x1c1c871caabca15828cf08ee3aa3199000b94ed15e743c3

# Generate El Gamal key pair
x, y = EG_KeyGen()

# Encrypt messages
r1, c1 = EG_Encrypt(m1)
r2, c2 = EG_Encrypt(m2)

# Homomorphically compute product of ciphertexts
r3 = (r1 * r2) % p
c3 = (c1 * c2) % p

# Decrypt homomorphic product
m3 = EG_Decrypt(r3, c3, x)

# Assess if homomorphic product equals product of plaintexts
assert m3 == (m1 * m2) % p

# Decode homomorphic product to bytes
m3_bytes = int_to_bytes(m3)
print("Homomorphic product:", m3_bytes.hex())
print("the value of m3 is equal to:", m3)

# Define messages
m1 = 1
m2 = 0
m3 = 1
m4 = 1
m5 = 0

# Generate El Gamal key pair
x, y = EG_KeyGen()

# Encrypt messages
r1, c1 = EGA_Encrypt(m1)
r2, c2 = EGA_Encrypt(m2)
r3, c3 = EGA_Encrypt(m3)
r4, c4 = EGA_Encrypt(m4)
r5, c5 = EGA_Encrypt(m5)
print("the value of r1 is equal to:", r1)
print("the value of r2 is equal to:", r2)
print("the value of r3 is equal to:", r3)
print("the value of r4 is equal to:", r4)
print("the value of r5 is equal to:", r5)

# Homomorphically compute product of ciphertexts
r = (r1 * r2 * r3 * r4 * r5) % p
c = (c1 * c2 * c3 * c4 * c5) % p

# Decrypt homomorphic product
m = EG_Decrypt(r, c, x)
print("m value is equal to:", m)

# Verify that m = m1 + m2 + m3 + m4 + m5
assert m == (m1 + m2 + m3 + m4 + m5) % p
print(f"Additive Version: Decoded m = {m}")
