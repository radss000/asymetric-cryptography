from rfc7448 import x25519, add, sub, computeVcoordinate, mult
from algebra import mod_inv, int_to_bytes
from random import randint

PRIME = 2**255 - 19
ORDER = 2**252 + 27742317777372353535851937790883648493

BASE_X = 9
BASE_Y = computeVcoordinate(BASE_X)

def brute_ec_log(point1, point2, prime):
    s1, s2 = 1, 0
    for i in range(prime):
        if s1 == point1 and s2 == point2:
            return i
        s1, s2 = add(s1, s2, BASE_X, BASE_Y, prime)
    return -1

def eg_encode(message):
    if message == 0:
        return (1, 0)
    if message == 1:
        return (BASE_X, BASE_Y)

def ec_eg_generate_keys():
    private_key = randint(2, 40)
    public_key = mult(private_key, BASE_X, BASE_Y, PRIME)
    return (private_key, public_key)

def ec_eg_encrypt(message, public_key):
    while True:
        random_int = randint(2, 40)
        ciphertext_x = mult(random_int, BASE_X, BASE_Y, PRIME)
        ciphertext_y = add(*eg_encode(message), *mult(random_int, *public_key, PRIME), PRIME)
        if computeVcoordinate(ciphertext_x[0]) == ciphertext_x[1] and computeVcoordinate(ciphertext_y[0]) == ciphertext_y[1]:
            return (ciphertext_x, ciphertext_y)

def ec_eg_decrypt(ciphertext, private_key):
    ciphertext_x, ciphertext_y = ciphertext
    secret = mult(private_key, *ciphertext_x, PRIME)
    message = brute_ec_log(*sub(*ciphertext_y, *secret, PRIME), PRIME)
    return message

if __name__ == "__main__":
    private_key, public_key = ec_eg_generate_keys()
    messages = [1, 0, 1, 1, 0]
    ciphertexts = [ec_eg_encrypt(message, public_key) for message in messages]
    r = (0, 0)
    c = (0, 0)
    for ciphertext in ciphertexts:
        r = add(*r, *ciphertext[0], PRIME)
        c = add(*c, *ciphertext[1], PRIME)

    decryption = ec_eg_decrypt((r, c), private_key)
    if decryption == sum(messages):
        print("Success! Decrypted message is: {}".format(decryption))
        print("The ElGamal encryption is additive homomorphic")
    else:
        print("Assessment failed!")
        print("Decrypted message is: {}".format(decryption))
        print("The sum of the messages is: {}".format(sum(messages)))
        print("The ElGamal encryption is supposed to be additive homomorphic")

