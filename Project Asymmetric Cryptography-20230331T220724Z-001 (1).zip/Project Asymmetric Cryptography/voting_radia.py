import random
import hashlib
import secrets
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric import dsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

# Parameters
MODP_GROUP = 2048
HASH_ALGORITHM = hashes.SHA256()
CURVE = ec.SECP256K1()
NUM_VOTERS = 10
NUM_CANDIDATES = 5

# Voter signature key generation and distribution
voter_keys = []
for i in range(NUM_VOTERS):
    private_key = dsa.generate_private_key(key_size=MODP_GROUP, backend=default_backend())
    public_key = private_key.public_key()
    voter_keys.append((private_key, public_key))

# Ballot generation

ballots = []
for i in range(NUM_VOTERS):
    ballot = []
    for j in range(NUM_CANDIDATES):
        message = str(j).encode()
        elgamal = ec.generate_private_key(CURVE, default_backend()).public_key()
        r = random.randint(0, CURVE.order - 1)
        c1 = CURVE.generator() * r
        c2 = (elgamal.public_numbers().y * r) + int.from_bytes(hashlib.sha256(message).digest(), 'big')
        ballot.append((c1, c2))
    ballots.append(ballot)


# Ballot multiplication (for El Gamal) or addition (for EC El Gamal)
multiplied_ballots = []
for i in range(NUM_CANDIDATES):
    c1_accum = CURVE.generator()
    c2_accum = 0
    for j in range(NUM_VOTERS):
        c1_accum += ballots[j][i][0]
        c2_accum += ballots[j][i][1]
    multiplied_ballots.append((c1_accum, c2_accum))

# Decryption and brute force search to recover election result
results = [0] * NUM_CANDIDATES
for i in range(NUM_CANDIDATES):
    for j in range(NUM_VOTERS):
        private_key = voter_keys[j][0]
        c1 = multiplied_ballots[i][0]
        c2 = multiplied_ballots[i][1]
        s = (c1 * private_key.private_numbers().x).public_numbers().y
        m = (c2 - s) % CURVE.order()
        for k in range(NUM_CANDIDATES):
            if int.from_bytes(hashlib.sha256(str(k).encode()).digest(), 'big') == m:
                results[k] += 1
                break

print("Election results:")
for i in range(NUM_CANDIDATES):
    print(f"Candidate {i}: {results[i]} votes")
